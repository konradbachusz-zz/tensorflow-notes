
# coding: utf-8

# ## Sentiment Analysis of Reviews using RNNs in TensorFlow, with pre-built embeddings
# 
# Modified from original code here: https://github.com/adeshpande3/LSTM-Sentiment-Analysis/blob/master/Oriole%20LSTM.ipynb

# #### Some imports to make code compatible with Python 2 as well as 3

# In[1]:

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


# In[2]:

import collections
import math
import os
import random
import tarfile
import re


# In[3]:

from six.moves import urllib


# In[4]:

import numpy as np
import matplotlib as mp
import matplotlib.pyplot as plt
import tensorflow as tf


# In[5]:

print(np.__version__)
print(mp.__version__)
print(tf.__version__)


# #### Download, unzip and untar files in an automated way

# In[6]:

DOWNLOADED_FILENAME = 'ImdbReviews.tar.gz'

def download_file(url_path):
    if not os.path.exists(DOWNLOADED_FILENAME):
        filename, _ = urllib.request.urlretrieve(url_path, DOWNLOADED_FILENAME)

    print('Found and verified file from this path: ', url_path)
    print('Downloaded file: ', DOWNLOADED_FILENAME)


# ### Extract reviews and the corresponding positive and negative labels from the dataset

# In[7]:

TOKEN_REGEX = re.compile("[^A-Za-z0-9 ]+")


def get_reviews(dirname, positive=True):
    label = 1 if positive else 0

    reviews = []
    labels = []
    for filename in os.listdir(dirname):
        if filename.endswith(".txt"):
            with open(dirname + filename, 'r+') as f:
                review = f.read().decode('utf-8')
                review = review.lower().replace("<br />", " ")
                review = re.sub(TOKEN_REGEX, '', review)
                
                reviews.append(review)
                labels.append(label)
    
    return reviews, labels           

def extract_labels_data():
    # If the file has not already been extracted
    if not os.path.exists('aclImdb'):
        with tarfile.open(DOWNLOADED_FILENAME) as tar:
            tar.extractall()
            tar.close()
        
    positive_reviews, positive_labels = get_reviews("aclImdb/train/pos/", positive=True)
    negative_reviews, negative_labels = get_reviews("aclImdb/train/neg/", positive=False)

    data = positive_reviews + negative_reviews
    labels = positive_labels + negative_labels

    return labels, data


# In[8]:

URL_PATH = 'http://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz'

download_file(URL_PATH)


# In[9]:

labels, data = extract_labels_data()


# In[10]:

labels[:5]


# In[11]:

data[:5]


# In[12]:

len(labels), len(data)


# In[13]:

max_document_length = max([len(x.split(" ")) for x in data])
print(max_document_length)


# ### How many words to consider in each review?
# 
# Majority of the reviews fall under 250 words. This a number we've chosen based on some analysis of the data:
# 
# * Count the number of words in each file and divide by number of files to get an average i.e. **avg_words_per_file = total_words / num_files**
# * Plot the words per file on matplot lib and try find a number which includes a majority of files
# 
# Word embeddings all have the same dimensionality which you can specify. A document is a vector of word embeddings (one dbpedia instance is a document in this case)
# 
# * Each document should be of the **same length**, documents longer than the MAX_SEQUENCE_LENGTH are truncated to this length
# * The other documents will be **padded** by a special symbol to be the same max length

# In[14]:

MAX_SEQUENCE_LENGTH = 250


# ### Use a pre-trained model for embeddings
# 
# Instead of training our model on our own dataset we will use a pre-trained model.
# 
# This is much better because these word vectors will be more generalized as they have been trained on a different dataset. These embeddings are trained using GloVe, a vector generation model very simalar to word2vec. 

# In[15]:

words = np.load('wordsList.npy')


# In[16]:

words[:5], len(words)


# ### Map every word to a unique index
# 
# The words are in the order and the position of the word in the word list is its index.

# In[17]:

def get_word_index_dictionary(words):
    
    dictionary = {}
    
    index = 0
    for word in words:
        dictionary[word] = index
        index += 1
    
    return dictionary

dictionary = get_word_index_dictionary(words)        


# #### The most common words have lower index values

# In[18]:

dictionary['and'], dictionary['this'], dictionary['together'], dictionary['supreme']


# ### Convert the sentences so they're represented in the form of word indexes
# 
# Use the word index mapping that we created earlier in order to look up the index for individual words

# In[19]:

review_ids = []

def convert_reviews_to_ids(data, words):
    words_list = words.tolist()

    progress = 0
    for review in data:
        review_id = []
        
        index = 0
        for word in review:
            if index >= MAX_SEQUENCE_LENGTH:
                break;
            
            try:
                review_id.append(dictionary[word])
            except KeyError:
                review_id.append(0)
            
            index += 1
        if len(review_id) < MAX_SEQUENCE_LENGTH:
            review_id = np.pad(review_id, (0, MAX_SEQUENCE_LENGTH - index), 'constant')

        review_ids.append(np.array(review_id))
        progress += 1
        
        if progress % 1000 == 0:
            print("Completed: ", progress)


# In[20]:

convert_reviews_to_ids(data, words)


# In[21]:

review_ids[19825]


# ### Load this saved file to get the reviews in the IMDB dataset represented using word indexes
# 
# These have been pre-calculated and saved, and will help you if your id mapping code takes too long to run

# In[22]:

review_ids = np.load('idsMatrix.npy')


# In[23]:

review_ids.shape


# In[24]:

review_ids[:5]


# In[25]:

x_data = review_ids
y_output = np.array(labels)

vocabulary_size = len(words)
print(vocabulary_size)


# In[26]:

data[3:5]


# In[27]:

x_data[3:5]


# In[28]:

y_output[:5]


# #### Shuffle the data so the training instances are randomly fed to the RNN

# In[29]:

np.random.seed(22)
shuffle_indices = np.random.permutation(np.arange(len(x_data)))

x_shuffled = x_data[shuffle_indices]
y_shuffled = y_output[shuffle_indices]


# In[30]:

TRAIN_DATA = 5000
TOTAL_DATA = 6000

train_data = x_shuffled[:TRAIN_DATA]
train_target = y_shuffled[:TRAIN_DATA]

test_data = x_shuffled[TRAIN_DATA:TOTAL_DATA]
test_target = y_shuffled[TRAIN_DATA:TOTAL_DATA]


# In[31]:

tf.reset_default_graph()

x = tf.placeholder(tf.int32, [None, MAX_SEQUENCE_LENGTH])
y = tf.placeholder(tf.int32, [None])


# In[32]:

batch_size = 25
embedding_size = 50
max_label = 2


# ### Embeddings to represent words
# 
# These embeddings have been pre-built using GloVe a word vector embedding algorithm just like word2vec. The matrix will contain 400,000 word vectors, each with a dimensionality of 50.
# 
# * *saved_embeddings* This is a matrix which holds the embeddings for every word in the vocabulary. The values have been pre-loaded and were generated using the GloVe algorithm
# * *embeddings* The embeddings for the words which are input as a part of one training batch

# In[33]:

saved_embeddings = np.load('wordVectors.npy')
embeddings = tf.nn.embedding_lookup(saved_embeddings, x)


# In[34]:

saved_embeddings


# In[35]:

embeddings


# In[36]:

lstmCell = tf.contrib.rnn.BasicLSTMCell(embedding_size)
lstmCell = tf.contrib.rnn.DropoutWrapper(cell=lstmCell, output_keep_prob=0.75)


# ### Results from an RNN of LSTM cells
# 
# (ouput, (**final_state**, other_state_info))
# 
# We're interested in the final state of this RNN because those are the encodings we feed into the prediction layer of our neural network

# In[37]:

_, (encoding, _) = tf.nn.dynamic_rnn(lstmCell, embeddings, dtype=tf.float32)


# In[38]:

encoding


# #### A densely connected prediction layer
# 
# * *activation=None* because the activation will be part of the tf.nn.sparse_softmax_cross_entropy_with_logits
# * *cross_entropy* the loss function for probability distributions
# * *max_label* the number of outputs of the prediction layer, here is 2, positive or negative

# In[39]:

logits = tf.layers.dense(encoding, max_label, activation=None)


# In[40]:

cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=logits, labels=y)
loss = tf.reduce_mean(cross_entropy)


# #### Find the output with the highest probability and compare against the true label

# In[41]:

prediction = tf.equal(tf.argmax(logits, 1), tf.cast(y, tf.int64))
accuracy = tf.reduce_mean(tf.cast(prediction, tf.float32))


# In[42]:

optimizer = tf.train.AdamOptimizer(0.01)
train_step = optimizer.minimize(loss)


# In[ ]:

num_epochs = 20


# In[43]:

init = tf.global_variables_initializer()


# In[44]:

with tf.Session() as session:
    init.run()
    
    for epoch in range(num_epochs):
        
        num_batches = int(len(train_data) // batch_size) + 1
        
        for i in range(num_batches):
            # Select train data
            min_ix = i * batch_size
            max_ix = np.min([len(train_data), ((i+1) * batch_size)])

            x_train_batch = train_data[min_ix:max_ix]
            y_train_batch = train_target[min_ix:max_ix]
            
            train_dict = {x: x_train_batch, y: y_train_batch}
            
            
            session.run(train_step, feed_dict=train_dict)
            
            train_loss, train_acc = session.run([loss, accuracy], feed_dict=train_dict)

        test_dict = {x: test_data, y: test_target}
        test_loss, test_acc = session.run([loss, accuracy], feed_dict=test_dict)    
        print('Epoch: {}, Test Loss: {:.2}, Test Acc: {:.5}'.format(epoch + 1, test_loss, test_acc)) 


# In[ ]:




# In[ ]:




# In[ ]:




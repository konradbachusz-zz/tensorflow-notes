
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.contrib import layers
import tensorflow.contrib.learn as tflearn
from tensorflow.contrib import metrics


tf.logging.set_verbosity(tf.logging.INFO)

CSV_COLUMNS = ['Exited', 'CreditScore', 'Geography', 
               'Gender', 'Age', 'Tenure', 'Balance', 'NumOfProducts',
               'HasCrCard', 'IsActiveMember', 'EstimatedSalary', 'key']

LABEL_COLUMN = 'Exited'

DEFAULTS = [[0.0], [650.0], [1.0], [1.0],
            [38.0], [5.0], [75000.0], [1.0], 
            [1.0],[1.0], [200000.0],['nokey']]

# These are the raw input columns, and will be provided for prediction also
INPUT_COLUMNS = [
    layers.real_valued_column('CreditScore'),
    layers.real_valued_column('Geography'),
    layers.real_valued_column('Gender'),
    layers.real_valued_column('Age'),
    layers.real_valued_column('Tenure'),
    layers.real_valued_column('Balance'),
    layers.real_valued_column('NumOfProducts'),
    layers.real_valued_column('HasCrCard'),
    layers.real_valued_column('IsActiveMember'),
    layers.real_valued_column('EstimatedSalary'),  
]

def build_estimator(model_dir, hidden_units):
  (cscore, geo, gender, age, tenure, bal, noprod, hscard, ismember, esal) = INPUT_COLUMNS 
  return tf.contrib.learn.DNNClassifier(
      model_dir=model_dir,
      feature_columns=[cscore, geo, gender, age, tenure, bal, noprod, hscard, ismember, esal],  
      hidden_units=hidden_units or [4,2,1])


def serving_input_fn():
    feature_placeholders = {
        column.name: tf.placeholder(tf.float32, [None]) for column in INPUT_COLUMNS
    }
    features = {
      key: tf.expand_dims(tensor, -1)
      for key, tensor in feature_placeholders.items()
    }
    return tflearn.utils.input_fn_utils.InputFnOps(
      features,
      None,
      feature_placeholders
    )

def generate_csv_input_fn(filename, num_epochs=None, batch_size=512, mode=tf.contrib.learn.ModeKeys.TRAIN):
  def _input_fn():
    # could be a path to one file or a file pattern.
    input_file_names = tf.train.match_filenames_once(filename)

    filename_queue = tf.train.string_input_producer(
        input_file_names, num_epochs=num_epochs, shuffle=True)
    reader = tf.TextLineReader()
    _, value = reader.read_up_to(filename_queue, num_records=batch_size)

    value_column = tf.expand_dims(value, -1)

    columns = tf.decode_csv(value_column, record_defaults=DEFAULTS)

    features = dict(zip(CSV_COLUMNS, columns))

    label = features.pop(LABEL_COLUMN)

    return features, label

  return _input_fn


def get_eval_metrics():
  return {
     'accuracy': tflearn.MetricSpec(
                metric_fn=tf.metrics.accuracy, prediction_key="classes"),
  }

